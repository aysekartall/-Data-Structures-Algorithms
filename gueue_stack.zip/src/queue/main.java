package queue;

public class main {
	

	public static void main(String[] args) 
	{
	PriorityQueue prq = new PriorityQueue(5);
	prq.enqueue(2);
	prq.enqueue(7);
	prq.enqueue(6);
	prq.enqueue(3);
	prq.print();
	
	

}
}